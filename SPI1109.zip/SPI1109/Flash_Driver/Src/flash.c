#include "flash.h"
#include <stdio.h>


FLASH_STATE Flash_Init(void)
{

    return FLASH_STATE_OK;
}

void Flash_Read_ID(uint8_t* id)
{
    uint8_t cmd[4] = {READ_ID_CMD,0x00,0x00,0x00};

    Flash_Enable();

    if(HAL_SPI_Transmit(&hspi1,cmd,4,HAL_TIMEOUT) != FLASH_STATE_OK)
    {
        printf("Flash Transmit CMD Fail! \r\n");
    }
    if (HAL_SPI_Receive(&hspi1,id,2,HAL_TIMEOUT) != FLASH_STATE_OK)
    {
        printf("Flash Read ID Fail! \r\n");
    }
    
    Flash_Disable();
}